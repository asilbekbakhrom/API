public class DownloadFailedEventArgs : EventArgs
{
    public string? ErrorMessage { get; internal set; }
}